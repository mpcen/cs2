This is the solution to Programming Assignment #1 with the difference that the
input file format is different.

This reads a graph from an input file containing only one graph. There are five
input files, g1.txt through g5.txt. Also, the starting vertex is specified in
the code, not the input file.

The program is setup to run g1.txt through g5.txt with starting vertex 0 and
then run those files again with starting vertex 1.

This input corresponds to graphs.txt -- your program should load this.

Both versions of DFS are implemented here.

This program was used to generate the test cases for grading.

correct-output.txt and correct-out-pure-dfs.txt are the correct outputs for the
program with both versions of DFS.

